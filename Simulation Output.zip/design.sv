//design.sv code
module fifo_mem #(
    parameter data_width = 16,
    parameter addr_width = 4,
    parameter depth = 16
)(
    input  wire                  w_clk,
    input  wire                  w_en,
    input  wire                  w_rst,  
    input  wire                  full,   
    input  wire [addr_width-1:0] waddr,
    input  wire [data_width-1:0] d_in,
    
    input  wire                  r_clk,
    input  wire                  r_en,
    input  wire                  r_rst,  
    input  wire                  empty,  
    input  wire [addr_width-1:0] raddr,
    output wire [data_width-1:0] d_out 
);

  reg [data_width-1:0] mem [0:depth-1];

  always @(posedge w_clk) begin
    if (!full && w_en) begin  
      mem[waddr] <= d_in;
    end
  end


  assign d_out = mem[raddr]; 

endmodule







module w_clk_domain #(
    parameter ADDR_WIDTH = 4
)(
    input  wire                  w_clk,
    input  wire                  w_rst,
    input  wire                  w_en,
    input  wire [ADDR_WIDTH:0]   read_addr_gray_sync,

    output wire                  w_en_out,
    output wire [ADDR_WIDTH-1:0] write_addr,
    output reg  [ADDR_WIDTH:0]   write_addr_gray,
    output reg                   full
);

    reg  [ADDR_WIDTH:0] w_bin;
    wire [ADDR_WIDTH:0] w_bin_next;
    wire [ADDR_WIDTH:0] w_gray_next;
    wire                full_val;

    assign w_en_out = w_en & ~full;
    assign w_bin_next = w_bin + w_en_out;
    assign w_gray_next = (w_bin_next >> 1) ^ w_bin_next;
    assign write_addr = w_bin[ADDR_WIDTH-1:0];

    assign full_val = (w_gray_next == {~read_addr_gray_sync[ADDR_WIDTH:ADDR_WIDTH-1], 
                                        read_addr_gray_sync[ADDR_WIDTH-2:0]});

    always @(posedge w_clk or posedge w_rst) begin
        if (w_rst) begin
            w_bin           <= 0;
            write_addr_gray <= 0;
            full            <= 1'b0;
        end else begin
            w_bin           <= w_bin_next;
            write_addr_gray <= w_gray_next;
            full            <= full_val;
        end
    end
endmodule









module r_clk_domain #(
    parameter ADDR_WIDTH = 4
)(
    input  wire                  r_clk,
    input  wire                  r_rst,
    input  wire                  r_en,
    input  wire [ADDR_WIDTH:0]   write_addr_gray_sync,
    output wire                  r_en_out,
    output wire [ADDR_WIDTH-1:0] read_addr,
    output reg  [ADDR_WIDTH:0]   read_addr_gray,
    output reg                   empty
);
    reg  [ADDR_WIDTH:0] r_bin;
    wire [ADDR_WIDTH:0] r_bin_next;
    wire [ADDR_WIDTH:0] r_gray_next;
    wire                empty_val;

    assign r_en_out = r_en & ~empty;
    assign r_bin_next = r_bin + r_en_out;
    assign r_gray_next = (r_bin_next >> 1) ^ r_bin_next;
    assign read_addr = r_bin[ADDR_WIDTH-1:0];

    always @(posedge r_clk or posedge r_rst) begin
        if (r_rst) begin
            r_bin          <= 0;
            read_addr_gray <= 0;
            empty<=1'b1;
        end else begin
            r_bin          <= r_bin_next;
            read_addr_gray <= r_gray_next;
            empty<=empty_val;
        end
    end

    assign empty_val = (r_gray_next == write_addr_gray_sync);

endmodule



module synchronizer #(parameter ADDR_WIDTH = 4)(
    input  wire                  clk,
    input  wire                  rst,
    input  wire [ADDR_WIDTH:0]   d_in,  
    output reg  [ADDR_WIDTH:0]   d_out );
reg [ADDR_WIDTH:0] q1;
always @(posedge clk or posedge rst) begin
if (rst) begin
q1    <= 0;
d_out <= 0;
end else begin
q1    <= d_in; 
d_out <= q1;   
end
end
endmodule














module top #(  
    parameter DATA_WIDTH = 16,
    parameter ADDR_WIDTH = 4,
    parameter DEPTH = 16
)(
    input  wire                  w_clk,
    input  wire                  w_rst,
    input  wire                  w_en,
    input  wire [DATA_WIDTH-1:0] d_in,
    output wire                  full,   
    
    input  wire                  r_clk,
    input  wire                  r_rst,
    input  wire                  r_en,
    output wire [DATA_WIDTH-1:0] d_out,
    output wire                  empty    
);

    wire [ADDR_WIDTH-1:0] write_addr;
    wire [ADDR_WIDTH-1:0] read_addr;

    wire w_en_mem;
    wire r_en_mem;

    wire [ADDR_WIDTH:0] write_addr_gray;
    wire [ADDR_WIDTH:0] read_addr_gray;

    wire [ADDR_WIDTH:0] write_addr_gray_sync;
    wire [ADDR_WIDTH:0] read_addr_gray_sync;

    fifo_mem #(
        .data_width(DATA_WIDTH),
        .addr_width(ADDR_WIDTH),
        .depth(DEPTH)
    ) u_fifo_mem (
        .w_clk(w_clk),
        .w_en(w_en_mem),       
        .w_rst(w_rst),
        .full(full),            
        .waddr(write_addr),
        .d_in(d_in),
        
        .r_clk(r_clk),
        .r_en(r_en_mem),        
        .r_rst(r_rst),
        .empty(empty),          
        .raddr(read_addr),
        .d_out(d_out));

    w_clk_domain #(
        .ADDR_WIDTH(ADDR_WIDTH)
    ) s2 (
        .w_clk(w_clk),
        .w_rst(w_rst),
        .w_en(w_en),
        .read_addr_gray_sync(read_addr_gray_sync), 
        
        .w_en_out(w_en_mem),             
        .write_addr(write_addr),         
        .write_addr_gray(write_addr_gray),
        .full(full));

    r_clk_domain #(
        .ADDR_WIDTH(ADDR_WIDTH)
    ) s1 (
        .r_clk(r_clk),
        .r_rst(r_rst),
        .r_en(r_en),
        .write_addr_gray_sync(write_addr_gray_sync), 
        
        .r_en_out(r_en_mem),             
        .read_addr(read_addr),           
        .read_addr_gray(read_addr_gray), 
        .empty(empty));

    synchronizer #(
        .ADDR_WIDTH(ADDR_WIDTH)
    ) u_sync_r2w (
        .clk(w_clk),                   
        .rst(w_rst),
        .d_in(read_addr_gray),           
        .d_out(read_addr_gray_sync));

    synchronizer #(
        .ADDR_WIDTH(ADDR_WIDTH)
    ) u_sync_w2r (
        .clk(r_clk),                    
        .rst(r_rst),
        .d_in(write_addr_gray),          
        .d_out(write_addr_gray_sync));
endmodule
