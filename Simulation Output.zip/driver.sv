
class driver;
  virtual fifo_fif vif;  
  mailbox gen2driv; 
  int no_transaction;       
  
  function new(virtual fifo_fif vif, mailbox gen2driv);
    this.vif = vif;
    this.gen2driv = gen2driv;
  endfunction

  task reset;
    wait(vif.w_rst);
    $display("[DRV] RESET STARTED");
    vif.wr_en   <= 0;
    vif.rd_en   <= 0;
    vif.data_in <= 0;
    wait(!vif.w_rst);
    $display("[DRV] RESET ENDED");
  endtask

  task main; 
    forever begin
      transaction trans;
      gen2driv.get(trans);

      if(trans.wr_en && !vif.full) begin
        @(posedge vif.w_clk);
        vif.wr_en   <= 1;
        vif.data_in <= trans.data_in;
        @(posedge vif.w_clk);
        vif.wr_en   <= 0;
        vif.data_in <= 0;
        no_transaction++;                 
        trans.display("DRIVER-WRITE");
      end

      else if(trans.rd_en && !vif.empty) begin
        @(posedge vif.r_clk);
        vif.rd_en <= 1;
        @(posedge vif.r_clk);
        #1;
        trans.data_out = vif.data_out;
        vif.rd_en <= 0;
        no_transaction++;                 
        trans.display("DRIVER-READ");        
      end
      else begin
        no_transaction++;
      end
    end
  endtask
endclass