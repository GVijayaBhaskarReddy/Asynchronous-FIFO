class environment;
  generator gen;
  driver driv;
  monitor mon;
  scoreboard scb;

  mailbox  gen2driv; 
  mailbox  mon2scb;
  
  virtual fifo_fif vif;

  function new(virtual fifo_fif vif);
    this.vif = vif;
    gen2driv = new();
    mon2scb = new();
    
    gen = new(gen2driv);
    driv = new(vif, gen2driv);
    mon = new(vif, mon2scb);
    scb = new(mon2scb);
  endfunction
  
  task pre_test();
    driv.reset();
  endtask
  
  task test();
    fork
      gen.main();
      driv.main();
      mon.main();
      scb.main();
    join_none
  endtask
  
  task post_test();
    wait(gen.ended.triggered); 
    wait(gen.no_gen == driv.no_transaction);
//     wait(vif.empty ==1 );
    #800;
  endtask

  task run();
    pre_test();
    test();
    post_test();
    scb.report();
    $finish;
  endtask
endclass
