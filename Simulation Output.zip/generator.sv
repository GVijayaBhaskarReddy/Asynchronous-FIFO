class generator;
  transaction trans;
  mailbox gen2driv;
  int no_gen;      
  event ended;  

  function new(mailbox  gen2driv);
    this.gen2driv = gen2driv;
  endfunction

  task main;
    repeat(5) begin
      trans = new();
   	  trans.wr_en = 1;
      trans.rd_en = 0;
      trans.data_in = $urandom();
      trans.display("GENERATOR");
      gen2driv.put(trans);
    end
    repeat(no_gen) begin
      trans = new();
      if(!trans.randomize()) $fatal(1, "Randomization failed!");
      trans.display("GENERATOR");
      gen2driv.put(trans); 
    end
    -> ended;
  endtask
endclass

