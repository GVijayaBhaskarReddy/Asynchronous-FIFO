interface fifo_fif(input logic w_clk, r_clk, w_rst, r_rst);
  logic wr_en, rd_en;
  logic [15:0] data_in;
  logic [15:0] data_out;
  logic full, empty;


modport DRV(output wr_en, rd_en, data_in, w_rst, r_rst,
            input  full, empty, data_out, w_clk, r_clk);
modport MON(input wr_en, rd_en, data_in, data_out, 
            full, empty, w_clk, r_clk);
endinterface

//Driver can drie signals , 	Drives signals for Read
//Monitor	Observes signals for	Read Only