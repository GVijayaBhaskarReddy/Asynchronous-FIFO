class monitor;
  virtual fifo_fif vif;
  mailbox mon2scb;

  function new(virtual fifo_fif vif, mailbox mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction
  
  task main;
  fork
    forever begin
      @(posedge vif.w_clk); #1;
      if (vif.wr_en && !vif.full) begin
        transaction trans;
        trans = new();
        trans.wr_en   = 1;
        trans.rd_en   = 0;
        trans.data_in = vif.data_in;
        trans.full    = vif.full;    
        trans.empty   = vif.empty;   
        trans.sample_coverage();           
        mon2scb.put(trans);
        trans.display("MONITOR-WRITE");

      end
    end
    forever begin
      @(posedge vif.r_clk);
      #1;
      if (vif.rd_en && !vif.empty) begin
          transaction trans;        
          trans = new();
          trans.rd_en    = 1;
          trans.wr_en    = 0;
          trans.data_out = vif.data_out; 
          trans.full     = vif.full;   
          trans.empty    = vif.empty;  
          trans.sample_coverage();        
          mon2scb.put(trans);
          trans.display("MONITOR-READ");
        @(posedge vif.r_clk);
      end
    end
  join_none
endtask
  
endclass
