class scoreboard;
  
  bit [15:0] fifo_queue[$];//queue memory 
  int no_transaction ;
  int pass_count;  
  int fail_count;   
  mailbox mon2scb;

  function new(mailbox mon2scb);
    this.mon2scb = mon2scb;
    pass_count=0;
    fail_count=0;
  endfunction
  


  task main;

    forever begin
      transaction trans;
      mon2scb.get(trans);
      no_transaction++;
      
      if (trans == null) begin
        $error("[SCB] Null transaction");
        continue;
      end
//write
      if (trans.wr_en && !trans.rd_en) begin
        fifo_queue.push_back(trans.data_in);
        $display("[SCB] Pushed:%h QueueSize:%0d",
                  trans.data_in, fifo_queue.size());        
      end
//read
      else if (trans.rd_en && !trans.wr_en) begin
        if (fifo_queue.size() == 0) begin
          $error("[SCB] Underflow!");
          fail_count++;
        end else begin
          bit [15:0] expected_data;
          expected_data = fifo_queue.pop_front();

          if (trans.data_out !== expected_data) begin
            $error("[SCB] FAIL Read:%h Expected:%h",
                    trans.data_out, expected_data);
            fail_count++;
        end else begin
            $display("[SCB] PASS Read:%h", trans.data_out);
            pass_count++;
          end
          trans.display("SCOREBOARD");  
        end
      end
    end
  endtask
  
  function void report();
    $display("=========================================");
    $display("         SCOREBOARD FINAL REPORT         ");
    $display("=========================================");
    $display("Total Transactions : %0d", no_transaction);
    $display("PASS Count         : %0d", pass_count);
    $display("FAIL Count         : %0d", fail_count);
    $display("=========================================");
  endfunction
  
endclass
