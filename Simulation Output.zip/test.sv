class test;
  environment env;
  virtual fifo_fif vif;

  function new(virtual fifo_fif vif);
    this.vif = vif;
    env = new(vif);
  endfunction

  task run();
    $display("[TEST] Starting formal test sequence...");
    env.gen.no_gen = 50;
    env.run();
    $display("[TEST] Sequence Complete.");
  endtask
endclass
