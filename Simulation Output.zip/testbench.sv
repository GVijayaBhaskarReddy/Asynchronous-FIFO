
`include "interface.sv"
`include "transaction.sv" 
`include "generator.sv"
`include "driver.sv"
`include "monitor.sv"
`include "scoreboard.sv"
`include "environment.sv" 
`include "test.sv"        

module tb_top;
bit w_clk, r_clk, w_rst, r_rst;//the reset are done from here

initial w_clk = 0; always #5  w_clk = ~w_clk;
initial r_clk = 0; always #7 r_clk = ~r_clk;

fifo_fif tif(w_clk, r_clk, w_rst, r_rst);

top dut (
  .w_clk (tif.w_clk),
  .w_rst (tif.w_rst),
  .w_en  (tif.wr_en),
  .d_in  (tif.data_in),
  .full  (tif.full),
  .r_clk (tif.r_clk),
  .r_rst (tif.r_rst),
  .r_en  (tif.rd_en),
  .d_out (tif.data_out),
  .empty (tif.empty)
);

test t1;

initial begin
  $dumpfile("dump.vcd");
  $dumpvars(0, tb_top);
  
  w_rst = 1;  
  r_rst = 1;
  #10;
  w_rst = 0;
  r_rst = 0;
  
  t1 = new(tif);
  t1.run();
  #300;
  $finish;
end

endmodule
