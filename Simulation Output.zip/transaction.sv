class transaction;
  rand bit wr_en, rd_en;
  rand bit [15:0] data_in;
  bit [15:0] data_out;
  bit full, empty;
  
    constraint valid_op {
    wr_en || rd_en;       
    !(wr_en && rd_en);  
      rd_en dist {1:=60, 0:=40};
  }
  
  covergroup fifo_cg;
    
    // Write enable coverage
    cp_wr: coverpoint wr_en {
      bins write    = {1};  
      bins no_write = {0};  
    }
    
    // Read enable coverage
    cp_rd: coverpoint rd_en {
      bins read    = {1}; 
      bins no_read = {0};  
    }
    
    // Full flag coverage
    cp_full: coverpoint full {
      bins fifo_full     = {1};  
      bins fifo_not_full = {0};  
    }
    
    // Empty flag coverage
    cp_empty: coverpoint empty {
      bins fifo_empty     = {1};  
      bins fifo_not_empty = {0};  
    }
    
    // Data input range coverage
    cp_data_in: coverpoint data_in {
      bins low_data  = {[16'h0000:16'h3FFF]};  
      bins mid_data  = {[16'h4000:16'h7FFF]};  
      bins high_data = {[16'h8000:16'hBFFF]};  
      bins max_data  = {[16'hC000:16'hFFFF]}; 
    }
    
    // Data output range coverage
    cp_data_out: coverpoint data_out {
      bins low_out  = {[16'h0000:16'h3FFF]};
      bins mid_out  = {[16'h4000:16'h7FFF]};
      bins high_out = {[16'h8000:16'hBFFF]};
      bins max_out  = {[16'hC000:16'hFFFF]};
    }
    
    // Cross coverage — write when full
    cx_wr_full: cross cp_wr, cp_full {
      bins write_when_full     = binsof(cp_wr.write) 
                                 && binsof(cp_full.fifo_full);
      bins write_when_not_full = binsof(cp_wr.write) 
                                 && binsof(cp_full.fifo_not_full);
    }
    
    // Cross coverage — read when empty
    cx_rd_empty: cross cp_rd, cp_empty {
      bins read_when_empty     = binsof(cp_rd.read) 
                                 && binsof(cp_empty.fifo_empty);
      bins read_when_not_empty = binsof(cp_rd.read) 
                                 && binsof(cp_empty.fifo_not_empty);
    }
    
  endgroup

  // Constructor — create covergroup
  function new();
    fifo_cg = new();
  endfunction

  // Sample coverage
  function void sample_coverage();
    fifo_cg.sample();
  endfunction  
  
  
  
  
  function void display(string name);
    $display("================[%s]=======================",name);
    $display("[%s]|| WR:%b|| RD:%b ||DATA:%h ||FULL:%b|| EMPTY:%b ||DATA_OUT: %h||", name, wr_en, rd_en, data_in, full, empty,data_out);
//     $display("================[%s]=======================",name);
    
  endfunction
endclass